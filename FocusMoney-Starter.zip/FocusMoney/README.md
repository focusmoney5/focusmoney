# FocusMoney — starter app

This is a first working prototype of FocusMoney.

## What it does
- Tracks monthly income and expenses
- Tracks bills, savings goals and debts
- Calculates monthly money left
- Saves data locally in the browser on the current device
- Exports and imports a JSON backup
- Includes a service worker for offline loading after the app has been hosted and opened online once

## Important limitations
- This prototype does not connect to banks.
- Data does not sync between devices.
- No reminders or notifications yet.
- The offline service worker works when hosted on HTTPS (for example GitHub Pages), not by simply opening the HTML file from Files.
- Test thoroughly before selling. Do not promise financial advice, bank-grade security or guaranteed results.

## Publish free with GitHub Pages
1. Create a GitHub account.
2. Create a public repository named `focusmoney`.
3. Upload `index.html`, `manifest.webmanifest`, and `sw.js` to the repository root.
4. In repository Settings → Pages, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site. Open the HTTPS URL in Safari.
6. In Safari, use Share → Add to Home Screen.
7. Open the app once while online. Then test offline mode by enabling Airplane Mode.

This app is a prototype. Before selling, test it on multiple iPhones and browsers, improve accessibility, add a clear privacy policy, and confirm the applicable platform and tax requirements.
